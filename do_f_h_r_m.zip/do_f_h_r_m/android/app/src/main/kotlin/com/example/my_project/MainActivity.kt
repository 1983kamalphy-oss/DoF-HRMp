package com.mycompany.dofhrm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
