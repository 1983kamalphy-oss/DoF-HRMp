import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCyze3JUnx5FLb1wAUeh0YYZ3XKEgIOFyE",
            authDomain: "futterflow-60783.firebaseapp.com",
            projectId: "futterflow-60783",
            storageBucket: "futterflow-60783.firebasestorage.app",
            messagingSenderId: "711491258001",
            appId: "1:711491258001:web:cafaf7d3a857c6c0fda130",
            measurementId: "G-7KQRYDDMKY"));
  } else {
    await Firebase.initializeApp();
  }
}
