import '../database.dart';

class PassSDTable extends SupabaseTable<PassSDRow> {
  @override
  String get tableName => 'pass & S>D';

  @override
  PassSDRow createRow(Map<String, dynamic> data) => PassSDRow(data);
}

class PassSDRow extends SupabaseDataRow {
  PassSDRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => PassSDTable();

  String? get districtName => getField<String>('district_name');
  set districtName(String? value) => setField<String>('district_name', value);

  String? get adminPassword => getField<String>('admin_password');
  set adminPassword(String? value) => setField<String>('admin_password', value);
}
