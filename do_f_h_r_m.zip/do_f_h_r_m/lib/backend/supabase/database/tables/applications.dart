import '../database.dart';

class ApplicationsTable extends SupabaseTable<ApplicationsRow> {
  @override
  String get tableName => 'applications';

  @override
  ApplicationsRow createRow(Map<String, dynamic> data) => ApplicationsRow(data);
}

class ApplicationsRow extends SupabaseDataRow {
  ApplicationsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ApplicationsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  String get fullName => getField<String>('full_name')!;
  set fullName(String value) => setField<String>('full_name', value);

  String get nidNumber => getField<String>('nid_number')!;
  set nidNumber(String value) => setField<String>('nid_number', value);

  String? get govtEmployeeId => getField<String>('govt_employee_id');
  set govtEmployeeId(String? value) =>
      setField<String>('govt_employee_id', value);

  String get districtName => getField<String>('district_name')!;
  set districtName(String value) => setField<String>('district_name', value);

  String get applicationText => getField<String>('application_text')!;
  set applicationText(String value) =>
      setField<String>('application_text', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);
}
