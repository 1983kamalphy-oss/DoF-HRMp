import '../database.dart';

class MembershipsTable extends SupabaseTable<MembershipsRow> {
  @override
  String get tableName => 'memberships';

  @override
  MembershipsRow createRow(Map<String, dynamic> data) => MembershipsRow(data);
}

class MembershipsRow extends SupabaseDataRow {
  MembershipsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => MembershipsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get userName => getField<String>('user_name');
  set userName(String? value) => setField<String>('user_name', value);

  String? get designation => getField<String>('designation');
  set designation(String? value) => setField<String>('designation', value);

  String? get phone => getField<String>('phone');
  set phone(String? value) => setField<String>('phone', value);

  String? get districtName => getField<String>('district_name');
  set districtName(String? value) => setField<String>('district_name', value);

  String? get status => getField<String>('status');
  set status(String? value) => setField<String>('status', value);
}
