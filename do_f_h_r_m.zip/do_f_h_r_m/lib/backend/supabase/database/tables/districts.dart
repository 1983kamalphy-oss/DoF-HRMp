import '../database.dart';

class DistrictsTable extends SupabaseTable<DistrictsRow> {
  @override
  String get tableName => 'districts';

  @override
  DistrictsRow createRow(Map<String, dynamic> data) => DistrictsRow(data);
}

class DistrictsRow extends SupabaseDataRow {
  DistrictsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => DistrictsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  String get districtName => getField<String>('district_name')!;
  set districtName(String value) => setField<String>('district_name', value);

  String get divisionName => getField<String>('division_name')!;
  set divisionName(String value) => setField<String>('division_name', value);

  String? get adminPassword => getField<String>('admin_password');
  set adminPassword(String? value) => setField<String>('admin_password', value);

  String? get districtCode => getField<String>('district_code');
  set districtCode(String? value) => setField<String>('district_code', value);

  bool? get isConfigured => getField<bool>('is_configured');
  set isConfigured(bool? value) => setField<bool>('is_configured', value);

  DateTime? get updatedAt => getField<DateTime>('updated_at');
  set updatedAt(DateTime? value) => setField<DateTime>('updated_at', value);
}
