import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form_field_group_child4_model.dart';
export 'form_field_group_child4_model.dart';

class FormFieldGroupChild4Widget extends StatefulWidget {
  const FormFieldGroupChild4Widget({super.key});

  @override
  State<FormFieldGroupChild4Widget> createState() =>
      _FormFieldGroupChild4WidgetState();
}

class _FormFieldGroupChild4WidgetState
    extends State<FormFieldGroupChild4Widget> {
  late FormFieldGroupChild4Model _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FormFieldGroupChild4Model());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 0.0,
      height: 0.0,
    );
  }
}
