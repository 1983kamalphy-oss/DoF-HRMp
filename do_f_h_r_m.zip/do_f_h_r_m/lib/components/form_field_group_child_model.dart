import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'form_field_group_child_widget.dart' show FormFieldGroupChildWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FormFieldGroupChildModel
    extends FlutterFlowModel<FormFieldGroupChildWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
