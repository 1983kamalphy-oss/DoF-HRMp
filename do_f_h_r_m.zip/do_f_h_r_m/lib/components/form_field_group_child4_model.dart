import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'form_field_group_child4_widget.dart' show FormFieldGroupChild4Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FormFieldGroupChild4Model
    extends FlutterFlowModel<FormFieldGroupChild4Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
