import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'form_group_child_widget.dart' show FormGroupChildWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FormGroupChildModel extends FlutterFlowModel<FormGroupChildWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
