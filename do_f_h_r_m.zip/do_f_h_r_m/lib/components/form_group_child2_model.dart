import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'form_group_child2_widget.dart' show FormGroupChild2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class FormGroupChild2Model extends FlutterFlowModel<FormGroupChild2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
