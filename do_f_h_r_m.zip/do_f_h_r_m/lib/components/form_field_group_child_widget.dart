import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form_field_group_child_model.dart';
export 'form_field_group_child_model.dart';

class FormFieldGroupChildWidget extends StatefulWidget {
  const FormFieldGroupChildWidget({super.key});

  @override
  State<FormFieldGroupChildWidget> createState() =>
      _FormFieldGroupChildWidgetState();
}

class _FormFieldGroupChildWidgetState extends State<FormFieldGroupChildWidget> {
  late FormFieldGroupChildModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FormFieldGroupChildModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 0.0,
      height: 0.0,
    );
  }
}
