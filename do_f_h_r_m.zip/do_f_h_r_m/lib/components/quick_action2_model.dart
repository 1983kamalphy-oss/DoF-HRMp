import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'quick_action2_widget.dart' show QuickAction2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class QuickAction2Model extends FlutterFlowModel<QuickAction2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
