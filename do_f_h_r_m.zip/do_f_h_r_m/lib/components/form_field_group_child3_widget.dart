import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form_field_group_child3_model.dart';
export 'form_field_group_child3_model.dart';

class FormFieldGroupChild3Widget extends StatefulWidget {
  const FormFieldGroupChild3Widget({super.key});

  @override
  State<FormFieldGroupChild3Widget> createState() =>
      _FormFieldGroupChild3WidgetState();
}

class _FormFieldGroupChild3WidgetState
    extends State<FormFieldGroupChild3Widget> {
  late FormFieldGroupChild3Model _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FormFieldGroupChild3Model());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 0.0,
      height: 0.0,
    );
  }
}
