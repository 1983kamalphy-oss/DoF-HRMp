import '/components/notification_card_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'clean_modern_mobile_page2_widget.dart'
    show CleanModernMobilePage2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CleanModernMobilePage2Model
    extends FlutterFlowModel<CleanModernMobilePage2Widget> {
  ///  State fields for stateful widgets in this page.

  // Model for NotificationCard.
  late NotificationCardModel notificationCardModel;

  @override
  void initState(BuildContext context) {
    notificationCardModel = createModel(context, () => NotificationCardModel());
  }

  @override
  void dispose() {
    notificationCardModel.dispose();
  }
}
