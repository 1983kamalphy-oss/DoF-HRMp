import '/backend/supabase/supabase.dart';
import '/components/detail_row_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'application_detail_page_widget.dart' show ApplicationDetailPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ApplicationDetailPageModel
    extends FlutterFlowModel<ApplicationDetailPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for DetailRow.
  late DetailRowModel detailRowModel1;
  // Model for DetailRow.
  late DetailRowModel detailRowModel2;
  // Model for DetailRow.
  late DetailRowModel detailRowModel3;

  @override
  void initState(BuildContext context) {
    detailRowModel1 = createModel(context, () => DetailRowModel());
    detailRowModel2 = createModel(context, () => DetailRowModel());
    detailRowModel3 = createModel(context, () => DetailRowModel());
  }

  @override
  void dispose() {
    detailRowModel1.dispose();
    detailRowModel2.dispose();
    detailRowModel3.dispose();
  }
}
