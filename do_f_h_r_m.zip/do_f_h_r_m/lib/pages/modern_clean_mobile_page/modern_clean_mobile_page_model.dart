import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'modern_clean_mobile_page_widget.dart' show ModernCleanMobilePageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';

class ModernCleanMobilePageModel
    extends FlutterFlowModel<ModernCleanMobilePageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
