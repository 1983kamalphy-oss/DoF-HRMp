import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'modern_clean_mobile_page_model.dart';
export 'modern_clean_mobile_page_model.dart';

/// Design a modern, clean mobile screen for a status confirmation message.
///
/// In the center, place a subtle animated or static light-blue
/// success/pending checkmark icon inside a soft circular background. Below
/// the icon, write a bold main title in Bengali: "আপনার আবেদনটি জমা হয়েছে".
/// Directly underneath, add a clean secondary subtitle in dark grey: "জেলা
/// এডমিনের অনুমোদনের অপেক্ষায় রয়েছে". At the bottom, include a full-width
/// primary button with rounded corners labeled "হোম পেজে ফিরে যান". Use a
/// minimalist card layout with soft shadows, subtle pastel color tones, and
/// generous white space.vvvvvvvvvvvvvvvvv
class ModernCleanMobilePageWidget extends StatefulWidget {
  const ModernCleanMobilePageWidget({
    super.key,
    required this.selectedDistrict,
  });

  final String? selectedDistrict;

  static String routeName = 'ModernCleanMobilePage';
  static String routePath = '/modernCleanMobilePage';

  @override
  State<ModernCleanMobilePageWidget> createState() =>
      _ModernCleanMobilePageWidgetState();
}

class _ModernCleanMobilePageWidgetState
    extends State<ModernCleanMobilePageWidget> {
  late ModernCleanMobilePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ModernCleanMobilePageModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Column(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Spacer(),
            Padding(
              padding: EdgeInsets.all(24.0),
              child: Container(
                child: Container(
                  child: Padding(
                    padding: EdgeInsets.all(32.0),
                    child: Container(
                      child: Container(
                        alignment: AlignmentDirectional(0.0, 0.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              width: 120.0,
                              height: 120.0,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(9999.0),
                                shape: BoxShape.rectangle,
                              ),
                              alignment: AlignmentDirectional(0.0, 0.0),
                              child: Lottie.network(
                                'https://dimg.dreamflow.cloud/v1/lottie/blue+checkmark+success+animation',
                                width: 80.0,
                                height: 80.0,
                                fit: BoxFit.contain,
                                animate: true,
                              ),
                            ),
                            Column(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  'আপনার আবেদনটি জমা হয়েছে',
                                  textAlign: TextAlign.center,
                                  style: FlutterFlowTheme.of(context)
                                      .headlineSmall
                                      .override(
                                        font: GoogleFonts.interTight(
                                          fontWeight: FontWeight.bold,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .headlineSmall
                                                  .fontStyle,
                                        ),
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.bold,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .headlineSmall
                                            .fontStyle,
                                      ),
                                ),
                                Text(
                                  'জেলা এডমিনের অনুমোদনের অপেক্ষায় রয়েছে',
                                  textAlign: TextAlign.center,
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        font: GoogleFonts.inter(
                                          fontWeight:
                                              FlutterFlowTheme.of(context)
                                                  .bodyMedium
                                                  .fontWeight,
                                          fontStyle:
                                              FlutterFlowTheme.of(context)
                                                  .bodyMedium
                                                  .fontStyle,
                                        ),
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryText,
                                        letterSpacing: 0.0,
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .fontStyle,
                                        lineHeight: 1.4,
                                      ),
                                ),
                              ].divide(SizedBox(height: 16.0)),
                            ),
                          ].divide(SizedBox(height: 24.0)),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Spacer(),
            Container(
              decoration: BoxDecoration(
                color: FlutterFlowTheme.of(context).secondaryBackground,
                shape: BoxShape.rectangle,
              ),
              child: Padding(
                padding: EdgeInsets.all(24.0),
                child: Container(
                  child: Container(
                    width: 0.0,
                    height: 0.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
