import '/backend/supabase/supabase.dart';
import '/components/form_label_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'daily_report_submission_page_widget.dart'
    show DailyReportSubmissionPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DailyReportSubmissionPageModel
    extends FlutterFlowModel<DailyReportSubmissionPageWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for FormLabel.
  late FormLabelModel formLabelModel1;
  // Model for FormLabel.
  late FormLabelModel formLabelModel2;
  // Model for FormLabel.
  late FormLabelModel formLabelModel3;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Model for FormLabel.
  late FormLabelModel formLabelModel4;
  bool isDataUploading_uploadDataJif = false;
  List<FFUploadedFile> uploadedLocalFiles_uploadDataJif = [];
  List<String> uploadedFileUrls_uploadDataJif = [];

  @override
  void initState(BuildContext context) {
    formLabelModel1 = createModel(context, () => FormLabelModel());
    formLabelModel2 = createModel(context, () => FormLabelModel());
    formLabelModel3 = createModel(context, () => FormLabelModel());
    formLabelModel4 = createModel(context, () => FormLabelModel());
  }

  @override
  void dispose() {
    formLabelModel1.dispose();
    formLabelModel2.dispose();
    formLabelModel3.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();

    formLabelModel4.dispose();
  }
}
